from tkinter import *
from tkinter import ttk
from tkinter import messagebox






# Данные компонентов
processors = [
    #intel
    {"name": "Intel Core i9-14900K", "socket": "LGA1700", "power": 160,"cost":67499},
    {"name": "Intel Core i7-14700K", "socket": "LGA1700", "power": 253,"cost":48499},
    {"name": "Intel Core i7-12800H", "socket": "LGA1200", "power": 45,"cost":26990},
    {"name": "Intel Core i5-12600HX", "socket": "LGA1700", "power": 55,"cost":19679},
    {"name": "Intel Core i5-10400", "socket": "LGA1700", "power": 195,"cost":12499},
    #AMD
    {"name": "AMD Ryzen 9 7950X", "socket": "AM5", "power": 78,"cost":63499},
    {"name": "AMD Ryzen 7 7700X", "socket": "AM5", "power": 142,"cost":35299},
    {"name": "AMD Ryzen 9 5900X", "socket": "AM4", "power": 105,"cost":34299},
    {"name": "AMD Ryzen 9 PRO 6950H", "socket": "AM4", "power": 45,"cost":43673},
    {"name": "AMD Ryzen 5 5600X", "socket": "AM4", "power": 65,"cost":11699},
]

motherboards = [
    #Intel
    {"name": "ZX X99 D4M4", "socket": "LGA2011", "form_factor": "mATX", "ram_type": "DDR4","cost":3981},
    {"name": "ROG Rampage VI", "socket": "LGA2066", "form_factor": "Eatx", "ram_type": "DDR4","cost":110170},
    {"name": "TUF GAMING H670-PRO", "socket": "LGA1700", "form_factor": "Satx", "ram_type": "DDR4","cost":43180},
    {"name": "PRO Z790-A", "socket": "LGA1700", "form_factor": "Satx", "ram_type": "DDR4,DDR5","cost":22999},
    {"name": "MSI MAG Z790 TOMAHAWK WIFI", "socket": "LGA1700", "form_factor": "Satx", "ram_type": "DDR5","cost":24999},
    #AMD
    {"name": "ASRock B550M-HVS SE", "socket": "AM4", "form_factor": "mATX", "ram_type": "DDR4","cost":12891},
    {"name": "Gigabyte A520M K V2", "socket": "AM4", "form_factor": "mATX", "ram_type": "DDR4","cost":5799},
    {"name": "ASUS PRIME B650-PLUS", "socket": "AM5", "form_factor": "Satx", "ram_type": "DDR4","cost":22130},
    {"name": "MSI A520M-A PRO", "socket": "AM4", "form_factor": "mATX", "ram_type": "DDR4","cost":5499},
    {"name": "MSI B550M PRO-VDH", "socket": "AM4", "form_factor": "mATX", "ram_type": "DDR4","cost":11499},
]

graphics_cards = [
    #Nvidia
    {"name": "NVIDIA GeForce GTX 1060", "power": 125, "length": 270,"cost":17500},
    {"name": "NVIDIA GeForce RTX 4070 Ti", "power": 200, "length": 201,"cost":67800},
    {"name": "NVIDIA GeForce RTX 3050", "power": 115, "length": 181,"cost":20999},
    {"name": "NVIDIA Geforce RTX 2060 SUPER", "power": 175, "length": 222,"cost":26500},
    {"name": "NVIDIA GeForce RTX 3060 ", "power": 115, "length": 198,"cost":33999},
    #Amd
    {"name": "AMD Radeon R7 ", "power": 400, "length": 159,"cost":5228},
    {"name": "AMD Radeon RX 550", "power": 50, "length": 182,"cost":12757},
    {"name": "AMD Radeon 550", "power": 50, "length": 155,"cost":9419},
    {"name": "Radeon RX 6400 ", "power": 50, "length": 192,"cost":14256},
    {"name": "AMD Radeon RX 7900 XT ", "power": 130, "length": 194,"cost":33999},
]
cases = [
    {"name": "Fractal Design Meshify C", "max_gpu_length": 315, "max_cooler_height": 170, "form_factor": "mAtx,Satx","cost":29896},
    {"name": "NZXT H510", "max_gpu_length": 300, "max_cooler_height": 165, "form_factor": "mAtx,Satx","cost":14084},
    {"name": "Corsair 4000D Airflow", "max_gpu_length": 400, "max_cooler_height": 170, "form_factor": "mAtx,Satx","cost":13699},
    {"name": "be quiet! Pure Base 500DX", "max_gpu_length": 369, "max_cooler_height": 190, "form_factor": "mAtx,Satx","cost":12499},
    {"name": "Thermaltake V200", "max_gpu_length": 320, "max_cooler_height": 160, "form_factor": "mAtx,Satx","cost":9499},
    {"name": "Cooler Master MasterBox Q300L", "max_gpu_length": 360, "max_cooler_height": 159, "form_factor": "Eatx,mAtx,Satx","cost":3281},
    {"name": "Lian Li PC-O11 Dynamic", "max_gpu_length": 420, "max_cooler_height": 167, "form_factor": "mAtx,Satx","cost":9547},
    {"name": "Phanteks Eclipse P400A", "max_gpu_length": 400, "max_cooler_height": 160, "form_factor": "mAtx,Satx","cost":19049},
    {"name": "Thermaltake Versa H21", "max_gpu_length": 320, "max_cooler_height": 150, "form_factor": "mAtx,Satx","cost":6728},
    {"name": "Antec P120 Crystal", "max_gpu_length": 400, "max_cooler_height": 167, "form_factor": "Eatx,mAtx,Satx","cost":15070},
        
]

coolers = [
    {"name": "DeepCool AS500", "height": 142,"cost":2453},
    {"name": "Be quiet! Dark Rock 4", "height": 149,"cost":11299},
    {"name": "Thermalright AXP-200R", "height": 150,"cost":7799},
    {"name": "Deepcool AG400", "height": 92,"cost":2550},
    {"name": "Aerocool Cylon 4", "height": 127,"cost":4232},
]

power_supplies = [
    {"name": "GameMax GP-500G", "power": 550,"cost":7199},
    {"name": "Thermaltake Smart RGB", "power": 700,"cost":6499},
    {"name": "NZXT C650 Gold", "power": 650,"cost":16990},
]

LIST1 = None
LIST2 = None
LIST3 = None
LIST4 = None
LIST5 = None
LIST6 = None


processors2 = [
    #intel
    {"": 'Intel Core i9-14900K — 24 ядра, 32 потока; высокая производительность, отлично подходит для тяжелых задач и игр.'},
    {"": 'Intel Core i7-14700K — 20 ядер, 28 потоков; высокая производительность, подходит для многозадачности и игр.'},
    {"": 'Intel Core i7-12800H — мобильный чип, 14 ядер; хорош для мощных ноутбуков.'},
    {"": 'Intel Core i5-12600HX — 12 ядер; мобильный процессор с хорошим балансом производительности и энергопотребления.'},
    {"": 'Intel Core i5-10400 — 6 ядер, 12 потоков; бюджетный процессор для офисных и легких игровых ПК.'},
    #AMD
    {"": 'AMD Ryzen 9 7950X — 16 ядер, 32 потока; один из лучших для многозадачности и сложных вычислений.'},
    {"": 'AMD Ryzen 7 7700X — 8 ядер, 16 потоков; мощный процессор для игр и работы.'},
    {"": 'AMD Ryzen 9 5900X — 12 ядер, 24 потока; хорош для многозадачности и тяжелых приложений.'},
    {"": 'AMD Ryzen 9 PRO 6950H — 8 ядер, высокоэффективный мобильный процессор для рабочих ноутбуков.'},
    {"": 'AMD Ryzen 5 5600X — 6 ядер, 12 потоков; отличное соотношение цены и производительности для игр"'},
]

motherboards2 = [
    #Intel
    {"": 'ZX X99 D4M4 — для мощных процессоров; поддержка четырехканальной памяти.'},
    {"": 'ROG Rampage VI — high-end плата с поддержкой разгона, хороша для энтузиастов.'},
    {"": 'TUF GAMING H670-PRO — бюджетная плата для геймеров.'},
    {"": 'PRO Z790-A — поддержка новейших Intel CPU и DDR5.'},
    {"": 'MSI MAG Z790 TOMAHAWK WIFI — качественная плата с Wi-Fi и поддержкой DDR5.'},
    #AMD
    {"": 'ASRock B550M-HVS SE — бюджетная плата для AMD Ryzen с поддержкой DDR4.'},
    {"": 'Gigabyte A520M K V2 — простая и доступная плата для офисных и бюджетных систем.'},
    {"": 'ASUS PRIME B650-PLUS — поддержка новейших Ryzen 7000 и DDR5.'},
    {"": 'MSI A520M-A PRO — бюджетный вариант для офисных ПК.'},
    {"": 'MSI B550M PRO-VDH — хорошая плата среднего уровня для AMD Ryzen.'},
]

graphics_cards2 = [
    #Nvidia
    {"": 'NVIDIA GeForce GTX 1060 — популярна среди бюджетных геймеров; для игр на средних настройках.'},
    {"": 'NVIDIA GeForce RTX 4070 Ti — high-end карта для 4K игр.'},
    {"": 'NVIDIA GeForce RTX 3050 — базовая RTX для игр на средних/высоких настройках.'},
    {"": 'NVIDIA Geforce RTX 2060 SUPER — мощная для игр на высоких настройках и стриминга.'},
    {"": 'NVIDIA GeForce RTX 3060 — универсальная карта для игр на высоких настройках.'},
    #Amd
    {"": 'AMD Radeon R7 — устаревшая модель, подходит для офисных задач.'},
    {"": 'AMD Radeon RX 550 — бюджетная карта, больше для офисных ПК.'},
    {"": 'AMD Radeon 550 — аналогичная RX 550, подходит для простых задач.'},
    {"": 'Radeon RX 6400 — бюджетный вариант для современных игр на низких/средних настройках.'},
    {"": 'AMD Radeon RX 7900 XT — мощная карта для 4K игр.'},
]
cases2 = [
    {"":'Fractal Design Meshify C — хорошая вентиляция, стильный дизайн.'},
    {"": 'NZXT H510 — компактный, стильный корпус, хорош для сборок с небольшим количеством компонентов.'},
    {"": 'Corsair 4000D Airflow — оптимальная вентиляция, просторный.'},
    {"": 'be quiet! Pure Base 500DX — низкий уровень шума, хорошая вентиляция.'},
    {"": 'Thermaltake V200 — стильный, со стеклянной боковой панелью, RGB-подсветка.'},
    {"": 'Cooler Master MasterBox Q300L — компактный и легкий, для небольших сборок.'},
    {"": 'Lian Li PC-O11 Dynamic — много пространства, стеклянные панели, подходит для кастомного охлаждения.'},
    {"": 'Phanteks Eclipse P400A — воздушный поток, RGB, просторный.'},
    {"": 'Thermaltake Versa H21 — бюджетный, подходит для базовых сборок.'},
    {"": 'Antec P120 Crystal — просторный, стеклянные панели, для премиум сборок.'},  
]

power_supplies2 = [
    {"": 'GameMax GP-500G — 500 Вт, для бюджетных ПК.'},
    {"": 'Thermaltake Smart RGB — 600 Вт, RGB-подсветка, подходит для сборок среднего уровня.'},
    {"": 'NZXT C650 Gold — 650 Вт, высокий КПД (80 Plus Gold), для высокопроизводительных систем.'},
]



def configWin():
    global LIST1, LIST2, LIST3, LIST4, LIST5, LIST6
    def Exit():
        
        win2.withdraw()
        WinMain.deiconify()
        

    WinMain.withdraw()
    win2 = Tk()     # создаем корневой объект - окно
    win2.title("Pixel point")     # устанавливаем заголовок окна
    win2.geometry("800x600")    # устанавливаем размеры окна
    win2.resizable(width=False, height=False) # нельзя изменять размер окна окно
    label2 = Label(win2,text = "Конфигуратор ПК",background = "#2e75b5" ,font = ("Impact",20),width = (800), border = (2))
    label2.pack()
    




    
    canvas = Canvas(win2,bg="#f0f0f0", width=800, height=600)
    canvas.pack(anchor=CENTER, expand=1)

    canvas.create_rectangle(105,150 ,266, 190, fill="#f0f0f0", outline="#2e75b5")
    canvas.create_rectangle(305,150 ,466, 190, fill="#f0f0f0", outline="#2e75b5")
    canvas.create_rectangle(505,150 ,666, 190, fill="#f0f0f0", outline="#2e75b5")

    canvas.create_rectangle(105,274 ,266, 315, fill="#f0f0f0", outline="#2e75b5",)
    canvas.create_rectangle(305,274 ,466, 315, fill="#f0f0f0", outline="#2e75b5")
    canvas.create_rectangle(505,274 ,666, 315, fill="#f0f0f0", outline="#2e75b5")

    

    
    Label(win2,text="Процессоры",font = ("Impact")).place(x = 115,y = 175)
    Label(win2,text="Мат. платы",font = ("Impact")).place(x = 315,y = 175)
    Label(win2,text="Видеокарты",font = ("Impact")).place(x = 515,y = 175)
    Label(win2,text="Копусы",font = ("Impact")).place(x = 115,y = 300)
    Label(win2,text="Кулеры",font = ("Impact")).place(x = 315,y = 300)
    Label(win2,text="Блоки питания",font = ("Impact")).place(x = 515,y = 300)

    LIST1 = ttk.Combobox(win2,values = [p["name"] for p in processors])
    LIST1.place(x = 115,y = 200)
    LIST2 = ttk.Combobox(win2,values = [p["name"] for p in motherboards])
    LIST2.place(x = 315 ,y = 200)
    LIST3 = ttk.Combobox(win2,values = [p["name"] for p in graphics_cards])
    LIST3.place(x = 515,y = 200)
    LIST4 = ttk.Combobox(win2,values = [p["name"] for p in cases])
    LIST4.place(x = 115 ,y = 325)
    LIST5 = ttk.Combobox(win2,values = [p["name"] for p in coolers])
    LIST5.place(x = 315 ,y = 325)
    LIST6 = ttk.Combobox(win2,values = [p["name"] for p in power_supplies])
    LIST6.place(x = 515 ,y = 325)


    def check():
        processor = next((p for p in processors if p["name"] == LIST1.get()), None)
        motherboard = next((m for m in motherboards if m["name"] == LIST2.get()), None)
        gpu = next((g for g in graphics_cards if g["name"] == LIST3.get()), None)
        case = next((c for c in cases if c["name"] == LIST4.get()), None)
        cooler = next((cl for cl in coolers if cl["name"] == LIST5.get()), None)
        psu = next((ps for ps in power_supplies if ps["name"] == LIST6.get()), None)
        
    
        

        # Проверка на совместимость
        if processor and motherboard:
            if processor["socket"] != motherboard["socket"]:
                messagebox.showerror("Ошибка совместимости", "Сокет процессора и материнской платы не совпадают.")
                return
        

        if gpu and case:
            if gpu["length"] > case["max_gpu_length"]:
                messagebox.showerror("Ошибка совместимости", "Длина видеокарты превышает допустимую длину для выбранного корпуса.")
                return

        if cooler and case:
            if cooler["height"] > case["max_cooler_height"]:
                messagebox.showerror("Ошибка совместимости", "Высота кулера превышает допустимую высоту для выбранного корпуса.")
                return

        total_power = sum(component["power"] for component in [processor, gpu] if component)
        if  total_power > psu["power"]:
            messagebox.showerror("Ошибка совместимости", "Мощности блока питания недостаточно для выбранной конфигурации.")
            return
        

        messagebox.showinfo("Успех", "Все компоненты совместимы!")
       




    OK = Button(win2,text= "Проверить",command= check,font = ("Impact", 18),background = "#2e75b5")
    OK.place(x= 322, y = 495)
    Close = Button(win2,text= "закрыть",command= Exit,font = ("Impact", 18),background = "#2e75b5")
    Close.place(x= 330, y = 547)
  

    win2.mainloop()



def calculate_total():
    # Функция для открытия нового окна и подсчёта общей стоимости
    total_cost = 0
    selected_items = {
        LIST1.get(): processors,
        LIST2.get(): motherboards,
        LIST3.get(): graphics_cards,
        LIST4.get(): cases,
        LIST5.get(): coolers,
        LIST6.get(): power_supplies
    }
    
    # Поиск стоимости выбранных комплектующих
    for item, category in selected_items.items():
        if not item:
            messagebox.showerror("Ошибка", "Выберите все компоненты перед расчётом!")
            return
        for component in category:
            if component["name"] == item:
                total_cost += component["cost"]
                break
    
    # Открытие нового окна с итоговой стоимостью
    result_window = Tk()
    result_window.title("Итоговая стоимость ПК")
    result_window.geometry("500x100")
    result_label = Label(result_window, text=f"Общая стоимость выбранных комплектующих: {total_cost} руб.", font=("Impact", 14))
    result_label.pack(pady=20)
    close_button = Button(result_window, text="Закрыть", command=result_window.destroy,width=10,background = "#2e75b5" ,font = ("Impact"))
    close_button.pack(pady=5)
    result_window.resizable(False, False)
    result_window.mainloop()


def infoWin():
    # Создание нового окна для информации о комплектующих
    win3 = Tk()
    win3.title("Информация о комплектующих ПК")
    win3.geometry("1024x768")
    win3.iconbitmap(default="Logo.ico")
    

    # Создание текстового поля с прокруткой
    text_area = Text(win3, wrap=WORD, font=("Impact", 12))
    text_area.pack(expand=True, fill=BOTH)

    scrollbar = Scrollbar(text_area)
    scrollbar.pack(side=RIGHT, fill=Y)
    text_area.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=text_area.yview)

    # Функция для добавления информации о компонентах в текстовое поле
    def insert_component_info(component_list, title):
        text_area.insert(END, f"{title}:\n" + "="*len(title) + "\n\n")
        for component in component_list:
            info = ", ".join([f"{key}: {value}" for key, value in component.items()])
            text_area.insert(END, info + "\n\n")
        text_area.insert(END, "\n\n")

    # Вставляем информацию по каждой категории комплектующих
    insert_component_info(processors2, "Процессоры")
    insert_component_info(motherboards2, "Материнские платы")
    insert_component_info(graphics_cards2, "Видеокарты")
    insert_component_info(cases2, "Корпуса")
    insert_component_info(power_supplies2, "Блоки питания")

    # Делаем текстовое поле только для чтения
    text_area.config(state=DISABLED)

    win3.resizable(width=False, height=False)
    win3.mainloop()


  
WinMain = Tk()     # создаем корневой объект - окно
WinMain.title("Pixel point")     # устанавливаем заголовок окна
WinMain.geometry("1024x768")    # устанавливаем размеры окна

WinMain.iconbitmap(default="Logo.ico") # иконка программы


#Вверхний текст
labelMain = Label (text = "Главное меню",background = "#2e75b5" ,font = ("Impact", 42),width = (1024), border = (2))
labelMain.pack()

#Изображение
loadimage1 = PhotoImage(file ="Bt1.png")
loadimage2 = PhotoImage(file ="Bt2.png")
loadimage3 = PhotoImage(file ="Bt3.png")



btn1 = Button(image = loadimage1,command = configWin) # кнопка 1
btn1["border"] = "0"
btn1.pack(side = LEFT, padx = [110, 0], ipadx = 20, ipady = 120)

labelBt1 = Label (text = "Конфигурация\nкомплектующих ПК",font = ("Impact", 18)) # Текст под кнопкой 1
labelBt1.place(x = 145,y = 590)



btn3 = Button(image = loadimage3 ,command= calculate_total) # кнопка 3
btn3["border"] = "0"
btn3.pack(side = RIGHT, padx = [0, 110], ipadx = 20, ipady = 120,)

labelBt3 = Label (text = "Итог стоимости ПК",font = ("Impact", 18)) # Текст под  кнопкой 3
labelBt3.place(x = 675,y = 590)

btn2 = Button(image = loadimage2,command= infoWin) # кнопка 2
btn2["border"] = "0"
btn2.pack(side = RIGHT, padx = [0, 0], ipadx = 20, ipady = 120)

labelBt2 = Label (text = "Информация о\nкомплектующих ПК",font = ("Impact", 18)) # Текст под  кнопкой 2
labelBt2.place(x = 410,y = 590)


WinMain.resizable(width=False, height=False) # нельзя изменять размер окна окно
WinMain.mainloop()